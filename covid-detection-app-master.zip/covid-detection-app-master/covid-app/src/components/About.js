import React, { Component } from 'react'

export class About extends Component {
    render() {
        return (
            <div><br/><br/><br/><br/>
            
                <h3>COVID DETECTION TEAM 01</h3>
                <h5>SOS CHALLENGE </h5><br/><br/>
                <p>Task:  Identify a solution to regularly test/monitor Indiana’s citizens, 
                    quickly identify hotspots, and enable contact tracing and other measures to 
                    mitigate and limit further outbreaks.</p>
            </div>
        )
    }
}

export default About
